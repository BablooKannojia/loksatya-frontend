"use client";

import { useState } from "react";
import "../src/i18n/config.js";
import { LanguageSelect, Loading, OnEdit } from "../src/Context";
import { AdProvider } from "../src/Context/TopAdContext";
import { CategoriesProvider } from "../src/Context/CategoriesContext";

// Mirrors the provider tree that used to live in src/main.jsx and the
// top of src/App.jsx (Loading / LanguageSelect / OnEdit / Ad / Categories).
export default function Providers({ children }) {
  const [lang, setLang] = useState("ur");
  const [loading, setLoading] = useState(false);
  const [effect, setEffect] = useState(false);
  const [onEdit, setOnEdit] = useState(false);
  const [id, setId] = useState("");

  return (
    <CategoriesProvider>
      <AdProvider>
        <Loading.Provider value={{ loading, setLoading, effect, setEffect }}>
          <LanguageSelect.Provider value={{ lang, setLang }}>
            <OnEdit.Provider value={{ onEdit, setOnEdit, id, setId }}>
              {children}
            </OnEdit.Provider>
          </LanguageSelect.Provider>
        </Loading.Provider>
      </AdProvider>
    </CategoriesProvider>
  );
}
