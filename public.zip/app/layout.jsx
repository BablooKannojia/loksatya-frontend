import "./globals.css";
import "react-toastify/dist/ReactToastify.css";
import Providers from "./providers";
import Header from "../src/Components/Global/Header";
import Footer from "../src/Components/Global/Footer";
import MenuBelowSlider from "../src/Components/Global/MenuBelowSlider";

export const metadata = {
  title: "Loksatya News",
  description: "Latest news, videos, photos and visual stories",
};

export default function RootLayout({ children }) {
  return (
    <html lang="hi">
      <body>
        <Providers>
          {/* Header/MenuBelowSlider/Footer render on every non-admin route,
              same as the `!isAdminRoute` check in the old App.jsx. Since
              /dashboard is now its own route group (not built yet), this
              layout only needs to cover the public site for now. */}
          <Header />
          <MenuBelowSlider />
          {children}
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
