"use client";

import { useEffect, useState } from "react";
import "./style/index.css";
const logo = "/assets/Logo-new.PNG";
import { MdArrowDropDown } from "react-icons/md";
import { BiSolidSearch } from "react-icons/bi";
import { GiHamburgerMenu } from "react-icons/gi";
import { RxCross1 } from "react-icons/rx";
import { useContext } from "react";
import { LanguageSelect, Loading } from "../../Context";
import { useTranslation } from "react-i18next";
import axios from "axios";
import { API_URL } from "../../API";
import { useRouter } from "next/navigation";
import Select from "react-select";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { IoIosCloseCircle } from "react-icons/io";
import MobileHeader from "./MobileHeader";
import { IoHomeOutline } from "react-icons/io5"
import { useCategories } from "../../Context/CategoriesContext";

const Header = () => {
  const [isHamBurger, setIsHamBurger] = useState(false);
  const { } = useContext(LanguageSelect);
  const { setEffect, effect } = useContext(Loading);
  const { t, i18n } = useTranslation();
  const [topAd, setTopAd] = useState({});
  const [search, setSearch] = useState(false);
  const router = useRouter();
  const Navigation = router.push;
  // Use shared categories data
  const { categories, subcategories, loading: categoriesLoading } = useCategories();

  // Split into main items and overflow items
  const mainItems = categories.slice(0, 11);
  const extraItems = categories.slice(11);
  const itsItem2 = categories.map((item) => ({
    value: item.text,
    label: item.text,
  }));

  useEffect(() => {
    // Fetch top ad separately
    axios.get(`${API_URL}/ads?active=true&side=top`).then((data) => {
      const activeAds = data.data.filter((data) => data.active);
      const topAdData = activeAds.filter((data) => data.device === "laptop");
      setTopAd(topAdData.reverse()[0]);
    });
  }, []);

  useEffect(() => {
    if (topAd && topAd._id) {
      axios.get(`${API_URL}/ads/click?id=${topAd._id}`).then(() => { });
    }
  }, [topAd]);

  const onClickAd = async (id) => {
    try {
      const response = await axios.post(`${API_URL}/ads/click`, { id });
      console.log("Ad click response:", response.data);
    } catch (error) {
      console.error("Error updating ads:", error);
    }
  };

  if (categoriesLoading) {
    return null;
  }

  return (
    <>
      <MobileHeader listitem={extraItems} />

      <div className="header-main-area">
        {topAd && (
          <div className="">
            <a
              href={topAd?.link}
              target="_blank"
              onClick={() => {
                onClickAd(topAd._id);
              }}
              rel="noreferrer"
            >
              <img
                style={{
                  cursor: "pointer",
                  padding: "2px",
                }}
                className="top-header-img"
                src={topAd?.imgLink}
                alt=""
              />
            </a>
          </div>
        )}

        <div className="header-contianer">
          <div
            onClick={() => Navigation("/")}
            style={{
              cursor: "pointer",
            }}
            className="header-logo-box"
          >
            <img src={logo} alt="" />
          </div>
          <div className="header-row-box">
            <ul
              style={{ flexWrap: "wrap" }}
              className="header-row-box-items "
            >
              <li
                className="mr-2 flex gap-1 items-center"
                onClick={() => {
                  Navigation(`/`);
                  setEffect(!effect);
                }}
              >
                <span>
                  <IoHomeOutline />
                </span>
                <span>होम</span>
              </li>
              {
                <>
                  {mainItems.length > 0 &&
                    mainItems.map((item) => {
                      const subItems = subcategories[item.text] || [];
                      
                      <li key={item._id} className="relative list-none">
                        <DropdownMenu.Root>
                          <DropdownMenu.Trigger asChild>
                            <div
                              className="flex items-center cursor-pointer"
                              onClick={() => {
                                Navigation(`/itempage?item=${item.text}`);
                                setEffect((prev) => !prev);
                              }}
                            >
                              {item.text}

                              {subItems.length > 0 && (
                                <MdArrowDropDown size={18} />
                              )}
                            </div>
                          </DropdownMenu.Trigger>

                          {subItems.length > 0 && (
                            <DropdownMenu.Portal>
                              <DropdownMenu.Content
                                sideOffset={5}
                                className="bg-white rounded-md shadow-lg p-2 z-50"
                              >
                                {subItems.map((sub) => (
                                  <DropdownMenu.Item
                                    key={sub._id}
                                    className="px-3 py-2 cursor-pointer hover:bg-gray-100 rounded"
                                    onClick={() => {
                                      Navigation(
                                        `/itempage?item=${sub.category}&sub=${sub.text}`
                                      );
                                      setEffect((prev) => !prev);
                                    }}
                                  >
                                    {sub.text}
                                  </DropdownMenu.Item>
                                ))}
                              </DropdownMenu.Content>
                            </DropdownMenu.Portal>
                          )}
                        </DropdownMenu.Root>
                      </li>
                    })}
                </>
              }
              <li onClick={() => Navigation("/live")}>{t("h14")}</li>

              {extraItems.length > 0 && (
                <DropdownMenu.Root>
                  <DropdownMenu.Trigger asChild>
                    <li className="flex items-center cursor-pointer">
                      Display More
                      <MdArrowDropDown size={20} />
                    </li>
                  </DropdownMenu.Trigger>

                  <DropdownMenu.Portal>
                    <DropdownMenu.Content
                      side="bottom"
                      align="start"
                      sideOffset={6}
                      className="bg-white rounded-md shadow-xl p-2 min-w-[220px] z-50"
                    >
                      {extraItems.map((item) => {
                        const subs = subcategories[item.text] || [];

                        return (
                          <DropdownMenu.Sub key={item._id}>
                            <DropdownMenu.SubTrigger
                              className="flex justify-between items-center px-3 py-2 rounded cursor-pointer hover:bg-gray-100"
                            >
                              {item.text}

                              {subs.length > 0 && (
                                <MdArrowDropDown
                                  size={18} />
                              )}
                            </DropdownMenu.SubTrigger>

                            {subs.length > 0 && (
                              <DropdownMenu.Portal>
                                <DropdownMenu.SubContent
                                  sideOffset={5}
                                  className="bg-white rounded-md shadow-xl p-2 min-w-[220px]"
                                >
                                  {subs.map((sub) => (
                                    <DropdownMenu.Item
                                      key={sub._id}
                                      className="px-3 py-2 rounded cursor-pointer hover:bg-gray-100"
                                      onClick={() => {
                                        Navigation(
                                          `/itempage?item=${sub.category}&sub=${sub.text}`
                                        );

                                        setEffect((prev) => !prev);
                                      }}
                                    >
                                      {sub.text}
                                    </DropdownMenu.Item>
                                  ))}
                                </DropdownMenu.SubContent>
                              </DropdownMenu.Portal>
                            )}
                          </DropdownMenu.Sub>
                        );
                      })}
                    </DropdownMenu.Content>
                  </DropdownMenu.Portal>
                </DropdownMenu.Root>
              )}
              <li>
                <BiSolidSearch
                  onClick={() => {
                    setSearch(true);
                  }}
                  size={30}
                  color="white"
                  style={{
                    marginLeft: "10px",
                  }}
                />
              </li>
            </ul>
            <GiHamburgerMenu
              className="ham-burger"
              size={30}
              color="white"
              onClick={() => setIsHamBurger(true)}
            />
          </div>
        </div>
        <div
          className={`ham-burger-area `}
          style={{ display: isHamBurger ? "block" : "none" }}
        >
          <div className="header-row2-icons">
            <BiSolidSearch size={30} color="white" />
            <RxCross1
              size={30}
              color="white"
              onClick={() => setIsHamBurger(false)}
              className="ham-burger-area-cross-child"
            />
          </div>
          <ul className="header-row-box-items2">
            {mainItems.length > 0 &&
              mainItems.map((data) => {
                return (
                  <li
                    key={data._id}
                    onClick={() => {
                      setIsHamBurger(false);
                      Navigation(`/itempage?item=${data.text}`);
                      setEffect(!effect);
                    }}
                  >
                    {data.text} <MdArrowDropDown size={20} />
                  </li>
                );
              })}
            <li>
              {t("key")} <MdArrowDropDown size={30} />
            </li>
          </ul>
        </div>
      </div>
      {search ? (
        <div
          onClick={() => {
            setSearch(false);
          }}
          style={{
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.2)",
            position: "absolute",
            zIndex: 9999,
            top: 0,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{
              width: "100%",
              padding: "10px",
              display: "flex",
            }}
          >
            <div
              style={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
              }}
            >
              <div
                onClick={(e) => e.stopPropagation()}
                style={{
                  width: "70%",
                  marginTop: 88,
                }}
              >
                <Select
                  autoFocus
                  options={itsItem2}
                  placeholder="Search Category..."
                  isSearchable
                  classNamePrefix="header-search"
                  onChange={(selected) => {
                    if (!selected) return;

                    Navigation(`/itempage?item=${selected.value}`);
                    setSearch(false);
                  }}
                />
              </div>
              <div onClick={(e) => e.stopPropagation()}>
                <IoIosCloseCircle
                  onClick={() => setSearch(false)}
                  size={55}
                  style={{
                    padding: "10px",
                    marginLeft: 20,
                    marginTop: 79,
                    cursor: "pointer",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        <></>
      )}
    </>
  );
};

export default Header;